a = 0
a += 10
print('a is ', a)
