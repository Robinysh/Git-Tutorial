a = 0
a += 1

print(a)
