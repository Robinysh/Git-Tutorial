a = 0

print('This is a: {}'.format(a))
